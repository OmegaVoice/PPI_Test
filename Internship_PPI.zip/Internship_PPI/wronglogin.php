<!DOCTYPE html>
<html>
<head>
   
</head>

<body>
    <div class="main">
        
    </div>
            <label style="text-align: center;"><br>You Are Wrong! Please Input Correctly</label>
        </div>

        <div class="social-icons">
                        <a href="index.php">Back to login</a>
                        </div>
    </div>
   
</body>
</html>