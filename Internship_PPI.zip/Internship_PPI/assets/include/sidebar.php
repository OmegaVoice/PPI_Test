<!DOCTYPE html>
<html>
<head>
    <title>Library Management System</title>
    <link rel="stylesheet" type="text/css" href="assets/css/home.css">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</head>

<body>
<div class="sidebar">  
    <div class="sidebar-wrapper">
        <h4>Hello Folks! <i class="far fa-smile-beam"></i></h4>

        <button>
            <a href="book.php"><i class='fas fa-home'></i>&nbsp; &nbsp;Dashboard</a>
        </button><br>

        <button>
            <a href="user.php"><i class='fas fa-user-circle'></i>&nbsp; &nbsp;User List</a>
        </button><br>

        <button>
            <a href="borrowing.php"><i class='fas fa-book'></i>&nbsp; &nbsp;Borrowing</a>
        </button><br>
            
        <button>
            <a href="logout.php"><i class='fas fa-sign-out-alt'></i>&nbsp; &nbsp;Logout</a>
        </button><br>
    </div>
</div>

</body>
</html>