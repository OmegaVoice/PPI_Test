<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" href="favicon.png">
    <title>PPI ACCESS</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords"
        content="Login" />
    <!-- //Meta tag Keywords -->
    <link href="//fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <!--/Style-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <!--//Style-CSS -->
    <script src="https://kit.fontawesome.com/af562a2a63.js" crossorigin="anonymous"></script>
    

</head>

<body>
    <!-- form section start -->
    <section class="w3l-mockup-form">
    <header class="container">
        <div class="row">
        <div style="display:flex;flex-direction:column;">
		<img style="width: 200px;align-self:center;" src="app_logo.png" alt="">
	</div></div>                
    </header>
        <div class="container">
                    <div class="content-wthree validate-input" data-validate="Valid email/nik is required">
                        <form method="post" action="loginprocess.php?mod=login">
                            <input type="text" class="text" name="identity" placeholder="Email/NIP" required>
                            <input type="password" name="password" placeholder="Password" style="margin-bottom: 2px;" required>
                            <!--<p><a href="forgot-password.php" style="margin-bottom: 15px; display: block; text-align: right;">Forgot Password?</a></p>-->
                            <br><br>
                            
                            <!-- captcha-->
                            <div class="form-group">
                                <label class="col-form-label">CAPTCHA <i style="color:teal;cursor:pointer;font-size:14pt;" title="Refresh Captcha" class="fa fa-retweet" id="refresh-captcha"></i></label>
                                <div class="row">
                                    <div class="col-md-6">
                                    <div id="captcha.php" style="width: 200px; height: 50px; border: 0;" alt=" "></div>
                                    </div>
                                </div>
                            </div>
                        <!--validate captcha-->
                            <div class="wrap-input100 validate-input" data-validate="Valid CAPTCHA required">
                                <input class="input100" type="text" name="captcha">
                                <span class="focus-input100"></span>
                                <span class="label-input100">CAPTCHA</span>
                            </div>
                            <button name="submit" name="submit" class="btn" type="submit">Login</button>
                        </form>
                        <div class="social-icons">
                         <a href="register.php">Forgot Password?</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- //form -->
        </div>
    </section>
    <!-- //form section start -->
</body>

</html>