<?php

$conn = mysqli_connect("localhost", "root", "", "ppi");

if (!$conn) {
    echo "Connection Failed";
}