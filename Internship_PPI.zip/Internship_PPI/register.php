<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="icon" href="favicon.png">
    <title>PPI ACCESS</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords"
        content="Regist Form" />
    <!-- //Meta tag Keywords -->
    <link href="//fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <!--/Style-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <!--//Style-CSS -->
    <script src="https://kit.fontawesome.com/af562a2a63.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="captcha.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css"
        integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk"
        crossorigin="anonymous">
    <script src="captcha.js"></script>

</head>

<body>
    <!-- form section start -->
    <section class="w3l-mockup-form">
    <header class="container">
        <div class="row">
        <div style="display:flex;flex-direction:column;">
		<img style="width: 200px;align-self:center;" src="app_logo.png" alt="">
	 </div>                
    </header>
        <div class="container">
                    <div class="content-wthree">
                        <form method="post" action="loginprocess.php?mod=login">
                            <input type="text" class="text" name="identity" placeholder="NIP" required>
                            <input type="email" name="email" placeholder="Email" style="margin-bottom: 2px;" required>
                            <!--<p><a href="forgot-password.php" style="margin-bottom: 15px; display: block; text-align: right;">Forgot Password?</a></p>-->
                        </form>

                            <div class="form-group">
                                <label class="col-form-label">CAPTCHA <i style="color:teal;cursor:pointer;font-size:14pt;" title="Refresh Captcha" class="fa fa-retweet" id="refresh-captcha"></i></label>
                                <div class="row">
                                    <div class="form-group col-6">
                                    <div id="img-captcha"><img src="https://ppiaccess.ptppi.co.id/captcha/1692178776.1084.jpg" style="width: 200px; height: 50px; border: 0;" alt=" "></div>
                                    </div>
                                </div>
                            </div>
                            
                        <!--validate captcha-->
                            <div class="wrap-input100 validate-input" data-validate="Valid CAPTCHA required">
                                <input class="input100" type="text" name="captcha" id="captcha">
                                <span class="focus-input100"></span>
                                <span class="label-input100">CAPTCHA</span>
                            </div>

                            <button name="submit" name="submit" class="btn" type="submit">SEND EMAIL</button>
                      
                        <div class="social-icons">
                         <a href="index.php">Back to login</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- //form -->
            
	
        </div>
    </section>
    <!-- //form section start -->
</body>

</html>