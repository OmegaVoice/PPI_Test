<?php
        if (isset($_POST["submit"]))
           $email = $_POST["email"];
           $password = $_POST["password"];
           
           
           require_once "connect.php";


    
            
            $sql ="SELECT * FROM login WHERE email='$email' AND password='$password'";
            $stmt = mysqli_stmt_init($conn);
            $prepareStmt = mysqli_stmt_prepare($stmt,$sql);
			if($_GET['mod']=='login'){
				$Q=mysqli_query($conn,"SELECT * FROM login WHERE email='$email' AND password='$password'");
				$r=mysqli_fetch_array($Q);
				//check data
				if(mysqli_num_rows($Q)){
				$_SESSION['email']=$r['email'];
					$_SESSION['password']=$r['password'];
					header('location:welcome.php');	
				}
				else {
				header('location:wronglogin.php');	
				}
			}
		
			?>